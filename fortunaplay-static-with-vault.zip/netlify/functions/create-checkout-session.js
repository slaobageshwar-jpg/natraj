// Netlify Function: create-checkout-session
// Requires env: STRIPE_SECRET, STRIPE_PRICE (test mode values ok)
const stripe = require('stripe')(process.env.STRIPE_SECRET);

exports.handler = async (event) => {
  try {
    const { quantity, success_url, cancel_url } = JSON.parse(event.body || "{}");
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [{
        price: process.env.STRIPE_PRICE,
        quantity: Math.max(1, Number(quantity) || 1),
      }],
      success_url: success_url || 'https://example.com?ok=1',
      cancel_url: cancel_url || 'https://example.com?canceled=1',
    });
    return { statusCode: 200, body: JSON.stringify({ url: session.url }) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};
