FortunaPlay Lottery — Static Hosting
====================================

Branding applied + Test Checkout (simulated). Optional Stripe server is scaffolded.

Run locally
-----------
- Double-click `index.html` or
- Serve: `python -m http.server 8000` → http://localhost:8000

Enable real Stripe (optional)
-----------------------------
1. Use Netlify. Set env vars in the site dashboard:
   - `STRIPE_SECRET` (your secret key)
   - `STRIPE_PRICE` (a Price ID for one ticket, e.g., price_... in Test mode)
2. Deploy the folder. Ensure `netlify/functions/create-checkout-session.js` exists.
3. The site will POST to `/.netlify/functions/create-checkout-session` with the cart total.
4. Function creates a Checkout Session and returns `url`. Browser redirects there.

For now, “Test Checkout (Simulated)” records the purchase without real payment.
