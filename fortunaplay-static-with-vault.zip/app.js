// FortunaPlay static app with test checkout simulator
const NUMBERS_MAX = 49, PICKS_REQUIRED = 6, TICKET_PRICE = 5;

const $ = (sel)=>document.querySelector(sel);
const $$ = (sel)=>Array.from(document.querySelectorAll(sel));

const fmt = (v)=> v.toLocaleString(undefined,{style:"currency",currency:"USD"});
const toKey=(arr)=>arr.slice().sort((a,b)=>a-b).join("-");

const storage = {
  get(k,f){ try{ const v=localStorage.getItem(k); return v? JSON.parse(v):f }catch{return f} },
  set(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)) }catch{} },
  rm(k){ try{ localStorage.removeItem(k) }catch{} },
};

function nextDrawTime(){ const now=new Date(), next=new Date(now); next.setHours(20,0,0,0); if(next<=now) next.setDate(next.getDate()+1); return next; }

let selection=[], cart=storage.get("lottery_cart",[]), tickets=storage.get("lottery_tickets",[]), revenue=storage.get("lottery_revenue",0), payouts=storage.get("lottery_payouts",0), history=storage.get("lottery_history",[]), owner=storage.get("lottery_owner",{name:"",email:"",payout:"", pin:""}), jackpot=storage.get("lottery_jackpot",1_000_000), vault=storage.get("lottery_vault",{balance:0,history:[]});

function renderNumberGrid(){
  const grid=$("#numberGrid"); grid.innerHTML="";
  for(let n=1;n<=NUMBERS_MAX;n++){
    const b=document.createElement("button");
    b.className="ball"+(selection.includes(n)?" active":"");
    b.textContent=n;
    b.onclick=()=>toggleNumber(n);
    grid.appendChild(b);
  }
  $("#selectedList").textContent = selection.slice().sort((a,b)=>a-b).join(", ") || "—";
  $("#addToCart").disabled = selection.length !== PICKS_REQUIRED;
}
function toggleNumber(n){
  if(selection.includes(n)) selection = selection.filter(x=>x!==n);
  else { if(selection.length>=PICKS_REQUIRED) return; selection=[...selection,n]; }
  renderNumberGrid();
}
function quickPick(){
  const pool=Array.from({length:NUMBERS_MAX},(_,i)=>i+1);
  for(let i=pool.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [pool[i],pool[j]]=[pool[j],pool[i]]; }
  selection=pool.slice(0,PICKS_REQUIRED).sort((a,b)=>a-b);
  renderNumberGrid();
}
function addToCart(){
  cart.push({numbers:[...selection], qty:1});
  storage.set("lottery_cart", cart);
  selection=[]; renderNumberGrid(); renderCart();
}
function renderCart(){
  const list=$("#cartList"); list.innerHTML=""; let total=0;
  cart.forEach((it,idx)=>{
    const item=document.createElement("div"); item.className="cart-item";
    const qty=document.createElement("div"); qty.className="qty";
    qty.innerHTML=`<button data-a="dec" class="btn">−</button><span>${it.qty}</span><button data-a="inc" class="btn">+</button>`;
    qty.onclick=(e)=>{ if(e.target.dataset.a==="inc") it.qty++; if(e.target.dataset.a==="dec") it.qty=Math.max(1,it.qty-1); storage.set("lottery_cart",cart); renderCart(); };
    const del=document.createElement("button"); del.className="btn"; del.textContent="Delete"; del.onclick=()=>{ cart.splice(idx,1); storage.set("lottery_cart",cart); renderCart(); };
    item.appendChild(document.createTextNode(it.numbers.slice().sort((a,b)=>a-b).join(" ")));
    item.appendChild(qty); item.appendChild(del); list.appendChild(item);
    total += TICKET_PRICE*it.qty;
  });
  $("#cartTotal").textContent = fmt(total);
}
function simulateCheckout(){
  const total = cart.reduce((s,it)=>s + it.qty*TICKET_PRICE, 0);
  if(total<=0) return alert("Cart is empty.");
  const name=$("#buyerName").value.trim(), email=$("#buyerEmail").value.trim();
  if(!name||!email) return alert("Enter name and email.");
  const purchase={ id:crypto.randomUUID?.():String(Date.now()), date:new Date().toISOString(), name,email, lines:cart.map(it=>({numbers:it.numbers, qty:it.qty})), total };
  tickets.unshift(purchase); revenue+=total;
  storage.set("lottery_tickets",tickets); storage.set("lottery_revenue",revenue);
  cart=[]; storage.set("lottery_cart", cart); renderCart(); renderAdmin(); renderAnalytics();
  alert("✅ Test checkout complete (simulated). No real payment processed.");
}
async function stripeCheckout(){
  alert("To enable Stripe: deploy Netlify function at '/.netlify/functions/create-checkout-session' and set STRIPE_SECRET + STRIPE_PRICE env vars. This button will POST your cart and redirect to Stripe Checkout.");
}

function generateWinningNumbers(){ const pool=Array.from({length:NUMBERS_MAX},(_,i)=>i+1); for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1)); [pool[i],pool[j]]=[pool[j],pool[i]]} return pool.slice(0,PICKS_REQUIRED).sort((a,b)=>a-b) }
function runDrawNow(){
  const winning = generateWinningNumbers(); let payoutTotal=0, winners=[];
  tickets.forEach(p=>p.lines.forEach(l=>{
    if(toKey(l.numbers)===toKey(winning)){ const prize=jackpot*l.qty; payoutTotal+=prize; winners.push({date:new Date().toISOString(), numbers:winning, name:p.name, prize}); }
  }));
  payouts+=payoutTotal; history.unshift({date:new Date().toISOString(), winning, payoutTotal, winnerCount:winners.length, winners});
  storage.set("lottery_payouts",payouts); storage.set("lottery_history",history);
  renderWinners(); renderAdmin(); alert(`Draw complete. Winning: ${winning.join(" ")}. Payouts: ${fmt(payoutTotal)}.`);
}
function renderWinners(){
  const list=$("#winnersList"); list.innerHTML="";
  if(history.length===0){ list.innerHTML=`<p class="muted">No draws yet. Use "Run Draw Now".</p>`; return; }
  history.forEach(h=>{
    const wrap=document.createElement("div"); wrap.className="card";
    const d=new Date(h.date).toLocaleString();
    wrap.innerHTML = `<div class="row between"><strong>${d}</strong><span class="badge">${h.winnerCount} winner(s)</span></div>
      <p>Winning numbers: <strong>${h.winning.join(" ")}</strong></p>
      <p>Payout total: <strong>${fmt(h.payoutTotal)}</strong></p>`;
    list.appendChild(wrap);
  });
}
function renderAdmin(){
  $("#revVal").textContent = fmt(revenue);
  $("#payVal").textContent = fmt(payouts);
  $("#profVal").textContent = fmt(revenue - payouts);
  $("#jackpotLabel").textContent = fmt(jackpot);
  $("#ownerName").value = owner.name||"";
  $("#ownerEmail").value = owner.email||"";
  $("#ownerPayout").value = owner.payout||"";
  $("#ownerNameFooter").textContent = owner.name || "FortunaPlay Owner";
  // Vault UI values
  const vbal = document.getElementById('vaultBalance'); if(vbal) vbal.textContent = fmt(vault.balance);
  const vprof = document.getElementById('profitNow'); if(vprof) vprof.textContent = fmt(currentProfit());
}
function saveOwner(){ owner={ name:$("#ownerName").value.trim(), email:$("#ownerEmail").value.trim(), payout:$("#ownerPayout").value.trim() }; storage.set("lottery_owner", owner); renderAdmin(); alert("Owner details saved locally."); }
function clearOwner(){ owner={name:"",email:"",payout:""}; storage.set("lottery_owner", owner); renderAdmin(); }

function renderAnalytics(){
  const days={};
  tickets.forEach(p=>{
    const day=new Date(p.date).toLocaleDateString();
    days[day]=(days[day]||{revenue:0,tickets:0});
    days[day].revenue+=p.total;
    days[day].tickets+=p.lines.reduce((s,l)=>s+l.qty,0);
  });
  const rows=Object.entries(days).sort((a,b)=> new Date(a[0]) - new Date(b[0]));
  const table=document.createElement("table"); table.style.width="100%"; table.style.borderCollapse="collapse";
  table.innerHTML="<thead><tr><th>Date</th><th>Revenue</th><th>Tickets</th></tr></thead>";
  const tb=document.createElement("tbody");
  rows.forEach(([d,val])=>{ const tr=document.createElement("tr"); tr.innerHTML=`<td>${d}</td><td>${fmt(val.revenue)}</td><td>${val.tickets}</td>`; tb.appendChild(tr); });
  table.appendChild(tb);
  const salesDiv=$("#salesTable"); salesDiv.innerHTML=""; salesDiv.appendChild(table);
  $("#exportCSV").onclick=()=>{
    const lines=[["Date","Revenue","Tickets"], ...rows.map(([d,v])=>[d,v.revenue,v.tickets])];
    const csv=lines.map(r=>r.map(x=>JSON.stringify(x)).join(",")).join("\n");
    const blob=new Blob([csv],{type:"text/csv"}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download="sales.csv"; a.click(); URL.revokeObjectURL(url);
  };
}
function setupTabs(){
  $$(".tab-btn").forEach(btn=>btn.addEventListener("click",(e)=>{
    e.preventDefault(); $$(".tab-btn").forEach(b=>b.classList.remove("active")); btn.classList.add("active");
    const tab=btn.dataset.tab; $$(".tab").forEach(s=>s.classList.remove("active")); $("#tab-"+tab).classList.add("active");
    if(tab==="winners") renderWinners(); if(tab==="admin") renderAdmin(); if(tab==="analytics") renderAnalytics();
  }));
}
function setupCountdown(){
  const el=$("#countdown"); function tick(){ const t=nextDrawTime().getTime()-Date.now(); const s=Math.max(0,Math.floor(t/1000)); const d=Math.floor(s/86400), h=Math.floor((s%86400)/3600), m=Math.floor((s%3600)/60), r=s%60; el.textContent=`${d?d+'d ':''}${String(h).padStart(2,'0')}h ${String(m).padStart(2,'0')}m ${String(r).padStart(2,'0')}s`; } tick(); setInterval(tick,1000);
}

// ---- Vault Helpers ----
function currentProfit(){ return Math.max(0, revenue - payouts); }

function sweepToVault(){
  const profit = currentProfit();
  const delta = profit - vault.balance;
  if (delta <= 0) { alert("No new profit to sweep."); return; }
  vault.balance += delta;
  vault.history.unshift({type:"sweep", amount:delta, date:new Date().toISOString()});
  storage.set("lottery_vault", vault);
  renderAdmin();
  alert(`✅ Swept ${fmt(delta)} to vault.`);
}
function setOwnerPIN(){
  const pin = prompt("Set/Update Owner PIN (4+ digits):", owner.pin || "");
  if(pin===null) return;
  owner.pin = String(pin).trim();
  storage.set("lottery_owner", owner);
  renderAdmin();
  alert("Owner PIN saved locally.");
}
function withdrawAll(){
  if(vault.balance<=0) { alert("Vault is empty."); return; }
  const pin = prompt("Enter Owner PIN to confirm withdrawal:");
  if((owner.pin||"") === "" || pin !== owner.pin){ alert("❌ Invalid PIN. Set a PIN in Admin > Owner Info."); return; }
  const amt = vault.balance;
  vault.balance = 0;
  vault.history.unshift({type:"withdraw", amount:amt, date:new Date().toISOString(), to: owner.payout || owner.email || owner.name || "owner"});
  storage.set("lottery_vault", vault);
  renderAdmin();
  alert(`💸 Withdrawn ${fmt(amt)} to owner (${owner.payout || owner.email || owner.name || "owner"}). (Simulated)`);
}

function init(){
  $("#year").textContent = new Date().getFullYear();
  renderNumberGrid(); renderCart(); renderAdmin(); renderAnalytics(); setupTabs(); setupCountdown();
  $("#clearBtn").onclick=()=>{ selection=[]; renderNumberGrid(); };
  $("#quickBtn").onclick=quickPick;
  $("#addToCart").onclick=addToCart;
  $("#paySim").onclick=simulateCheckout;
  $("#payStripe").onclick=stripeCheckout;
  $("#runDraw").onclick=runDrawNow;
  $("#resetDemo").onclick=()=>{ if(!confirm("Reset all demo data?")) return; cart=[]; tickets=[]; revenue=0; payouts=0; history=[]; storage.set("lottery_cart",cart); storage.set("lottery_tickets",tickets); storage.set("lottery_revenue",revenue); storage.set("lottery_payouts",payouts); storage.set("lottery_history",history); renderCart(); renderWinners(); renderAdmin(); renderAnalytics(); };
  $("#saveOwner").onclick=saveOwner; $("#clearOwner").onclick=clearOwner; $("#sweepVault").onclick=sweepToVault; $("#withdrawAll").onclick=withdrawAll; $("#setPin").onclick=setOwnerPIN;
}
document.addEventListener("DOMContentLoaded", init);
